using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieAI : MonoBehaviour
{
    public GameObject Target;
    public float speed = 1.5f;

    void Update()
    {
        if (Target != null)
        {
            transform.LookAt(Target.transform);
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
        }
        else
        {
            Debug.LogWarning("Target GameObject not assigned!");
        }
    }

    private void OnDrawGizmosSelected()
    {
    }
}
